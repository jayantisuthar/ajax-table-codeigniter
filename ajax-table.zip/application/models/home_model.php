<?php 
Class Home_model extends CI_Model {

    // auto load "home-model" and "database"
    public function get_data(){
        $query = $this->db->get('employee');
        $result = $query->result();
        if($query->num_rows() != 0) 
        {
            return $result;
        }
         else {
             $this->session->set_flashdata('error', 'Error: No data available Or Unable to retrieve data');
            return false;
         }
    }

    // insert form data
    public function save_upload($data){
        $result= $this->db->insert('employee',$data);
        return $result;
    }

    // update inline row data
    public function update($up_data) {
        $this->db->where('id' , $up_data['id']);
        $result_update = $this->db->update('employee', $up_data);
        if($result_update) {
            return $this->db->affected_rows();
        }
    }

    public function delete($data) {

        $delete_result = $this->db->delete('employee', $data);
        if($delete_result) {
            return $delete_result;
        }

    } 




}


?>