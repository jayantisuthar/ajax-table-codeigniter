<?php 

Class Home extends CI_Controller {

    public function index() {
        
        $employee = $this->home_model->get_data();
       
        if(!empty($employee)) {

        $data['employee'] = $employee;
        $data['title'] = 'All Users Table';
      
        $this->load->view('home_view' , $data);
        }
        else {
        $data['title'] = 'All Users Table';
        $this->load->view('home_view' , $data);
        }
    }
    

    function do_upload(){

    
        $config['upload_path']= './assets/upload/';
        $config['allowed_types']='gif|jpg|png';
        $config['encrypt_name'] = TRUE;
        
        $this->load->library('upload', $config);

        if($this->upload->do_upload('userfile')){
            $data = array('upload_data' => $this->upload->data());
        }
        else {
            $data = array('upload_data' => '');
            echo $this->upload->display_errors('<p>', '</p>');
        }

        $data1 = array(
            'name' => $this->input->post('name'),
            'contact_no' => $this->input->post('contact_no'),
            'hobby' =>  implode(',', $this->input->post('hobby')),
            'category_id' => $this->input->post('category'),
            'image' => $data['upload_data']['file_name']
        );
       
        $result= $this->home_model->save_upload($data1);

        echo json_decode($result);
    }



    public function editrow(){


        // 'action' => $this->input->post('action'),
        $data = array(
            'id' => $this->input->post('id'),
            'name' => $this->input->post('name'),
            'contact_no' => $this->input->post('contact_no'),
            'hobby' => implode(',', $this->input->post('hobby')),
            'category_id' => $this->input->post('category')
        );

        $update = $this->home_model->update($data);


        if($update){

            $query = $this->db->query("SELECT * FROM employee ORDER BY id DESC LIMIT 1");
            $result = $query->result_array();
            

            $returnData = array(
                'status' => 'ok',
                'msg' => 'User data has been updated successfully.',
                'data' => $result
            );
        }

        else {
            $returnData = array(
                'status' => 'error',
                'msg' => 'Some problem occurred, please try again.',
                'data' => ''
            );
        }

         echo json_encode($returnData);
       
    }


    public function deleterow() {
        
        $id = $this->input->post('id');
        if(isset($id)) {    
        
            //delete data
            $condition = array('id' => $id);
            $delete = $this->home_model->delete($condition);

            $returnData = array(
                'status' => 'ok',
                'msg' => 'User data has been deleted successfully.'
            );
        }      

        else {

            $returnData = array(
                'status' => 'error',
                'msg' => 'Some problem occurred, please try again.'
            );
        }
    
        echo json_encode($returnData);


    }
 

    public function deleteAll()
    {
        $id = $this->input->post('ids');
 
        $this->db->where_in('id', explode(",", $id));
        $this->db->delete('employee');
 
        echo json_encode(['success'=>"Item Deleted successfully."]);
    }

}

?>