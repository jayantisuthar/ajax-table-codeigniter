<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
       <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" >
    <style>
    @import url('https://fonts.googleapis.com/css?family=Montserrat&display=swap');
    * { font-family: 'Montserrat', sans-serif;}
    </style>


    <title><?php echo $title;?></title>
</head>
<body>

<section id="section-table">
    <div class="container">
        <br><br>

    <h1 class="pull-left">Users Table </h1>

    <div class="pull-right">
        <a style="color:blue" onclick="showform();"><b>ADD NEW</b></a> |  
        <button class="delete_all" data-url="<?=base_url() ?>index.php/home/deleteAll/">Delete All Selected</button>
    </div>
   


<?php 
   if(empty($employee)) {
        echo $this->session->flashdata('error');
   } 
   else {
?>

    <table class="table table-responsive table-bordered table-striped">
    <thead>
        <tr>
            <th><input type="checkbox" id="master"></th>
            <th>Sr.</th>
            <th>Name</th>
            <th>Contact No.</th>
            <th>Hobby</th>
            <th>Category</th>
            <th>Profile Pic</th>
            <th>Edit</th>
        </tr> 
        </thead>
        <tbody>
        <?php  foreach($employee as $value)  { ?>


            <tr  id="<?php echo $value->id ?>">

                 <!-- multiple delete checkbox -->
                <td>
                    <!-- <input type="checkbox" class="delete_checkbox" id="select_all" name="" value="<?php echo $value->id ?>"/> -->
                    <input type="checkbox" class="sub_chk" data-id="<?php echo $value->id; ?>">
                </td>


                <td>
                    <?php echo $value->id ?>
                </td>
                
                <td>
                    <span class="editSpan name"><?php echo $value->name ?></span>

                    <input class="editInput name form-control input-sm" type="text" name="name" value="<?php echo $value->name ?>" style="display: none;">
                </td>

                <td>
                    <span class="editSpan contact_no"><?php echo $value->contact_no ?></span>

                    <input class="editInput contact_no form-control input-sm" type="text" name="contact_no" value="<?php echo $value->contact_no ?>" style="display: none;">
                </td>


                <td>
                
                    <span class="editSpan hobby hobby<?= $value->id ?>"><?php echo $value->hobby ?></span>
                    <div class="editInput"  style="display: none;">
                        <input class="editInput" id="hobby<?= $value->id ?>" type="checkbox" name="hobby[]" value="Programming">Programming |
                        <input class="editInput" id="hobby<?= $value->id ?>" type="checkbox" name="hobby[]" value="Games">Games<br>
                        <input class="editInput" id="hobby<?= $value->id ?>" type="checkbox" name="hobby[]" value="Reading"> Reading 
                        <input class="editInput" id="hobby<?= $value->id ?>" type="checkbox" name="hobby[]" value="Photography"> Photography
                    </div>
                 
                </td>


                <td>
                    <span class="editSpan category role<?= $value->id ?>"><?php echo $value->category_id ?></span>
                    
                    <select class="editInput" name="category" style="display:none;">4
                        <option id="role<?= $value->id ?>" value="Developer">Developer</option>
                        <option id="role<?= $value->id ?>" value="Designer">Designer</option>
                        <option id="role<?= $value->id ?>" value="HR">HR</option>
                        <option id="role<?= $value->id ?>" value="Managment">Management</option>
                    </select>
    
                </td>

                <td>
                 <img src= <?php echo base_url()."assets/upload/".$value->image ?> width='70px'>   
                </td>

                <td>

                    <div class="btn-group btn-group-sm">
                    
                        <button type="button" class="btn btn-sm btn-default editBtn" style="float: none;"><span class="glyphicon glyphicon-pencil"></span></button>
                       
                        <button type="button" class="btn btn-sm btn-default deleteBtn" style="float: none;"><span class="glyphicon glyphicon-trash"></span></button>
                    
                    </div>

                    <button type="button" class="btn btn-sm btn-success saveBtn" style="float: none; display: none;">Save</button>
                    <button type="button" class="btn btn-sm btn-danger confirmBtn" style="float: none; display: none;">Confirm</button>
                
                    <!-- <b> <a style='color:green' href=<?php // echo ".base_url()." ?> >Edit / </a><br> -->
                    <!-- <a style='color:red' href=<?php // echo ".base_url()." ?> >Delete</a> </b> -->
                </td>

            </tr>
            <?php } ?>
        </table>
    
   
    
    <?Php } ?>
    </div>
</section>





<!-- ************** *************** -->


<?php $this->load->view('add-user') ; ?>

<!-- **************************** -->


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <script src="<?php  echo   base_url();?>assets/js/custom.js"></script>

<script>




</script>


</body>
</html>