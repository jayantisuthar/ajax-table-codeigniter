

<section id="form-field" style="display:none;">
   <br><br>

<div class="container">

    <h1>Add Employee</h1>
    <p style="color:red">* All field Are mandatory</p>
    
    <?php $form2 = array(
        'id' => 'submit',
        'class'=>'form-horizotal'
    ); ?>


    <?php echo form_open_multipart('home/do_upload', $form2);?>

        <table class="table table-bordered">
            <tr>
                <td><b>Name</b></td>
                <td>
                    <input name="name" require type="text" class="form-control">
                </td>
            </tr>
            
            <tr>
                <td><b>Contact No.</b></td>
                <td>
                    <input name="contact_no" require type="text" class="form-control">
                </td>
            </tr>
            
            <tr>
                <td><b>Hobby</b></td>
                <td>
                    <input type="checkbox" require name="hobby[]" value="Programming"> Programming<br>
                    <input type="checkbox" require name="hobby[]" value="Games"> Games<br>
                    <input type="checkbox" require name="hobby[]" value="Reading"> Reading<br>
                    <input type="checkbox" require name="hobby[]" value="Photography"> Photography<br>
                </td>
            </tr>
            
            <tr>
                <td><b>Category</b></td>
                <td>
                    <select name="category" require>
                        <option value="Developer">Developer</option>
                        <option value="Designer">Designer</option>
                        <option value="HR">HR</option>
                        <option value="Management">Management</option>
                    </select>
                </td>
            </tr>
            
            <tr>
                <td><b>Profile Photo</b></td>
                <td>
                   
                    <input type="file" require name="userfile">
                </td>
            </tr>

            <tr>
                <td><a class="btn btn-warning pull-right" onclick="hideform()" >Cancel</a></td>
                <td>
                    <input class="btn btn-success" id="btn_upload" type="submit" value="upload" />
                </td>
            </tr>

        </table>             
    </form>

</div> 
  

</section>