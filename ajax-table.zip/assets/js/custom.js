function showform() {
	$(document).ready(function () {
		$("#section-table").hide();
		$("#form-field").show();
	});
}
function hideform() {
	$(document).ready(function () {

		$("#section-table").show();
		$("#form-field").hide();
	});
}

$('#submit').submit(function (e) {
	e.preventDefault();
	$.ajax({
		url: 'http://localhost/ajax-table/index.php/home/do_upload',
		type: "post",
		data: new FormData(this), //this is formData
		processData: false,
		contentType: false,
		cache: false,
		async: false,
		success: function (data) {
			alert("User Added Successful.");
			window.location.reload();
			
		}
	});
});

// ****************************************


$(document).ready(function () {
	$('.editBtn').on('click', function () {
		//hide edit span
		$(this).closest("tr").find(".editSpan").hide();

		//show edit input
		$(this).closest("tr").find(".editInput").show();

		//hide edit button
		$(this).closest("tr").find(".editBtn").hide();

		//show edit button
		$(this).closest("tr").find(".saveBtn").show();



		var ID = $(this).closest("tr").attr('id');
		var role = $(".role"+ID).html();
		
		$("option#role"+ID).each(function () {
			if($(this).val() == role) {
				$(this).attr("selected", "selected");
			}
		});
		
		
		var hobby_name = $(".hobby"+ID).html();

		$("input#hobby" + ID).each(function () {

			var str2 = $(this).val();
			if (hobby_name.includes(str2)) {

				$(this).attr('checked', true);
			//  console.log();
			}
		
		});
		
		
	});


	
	$('.saveBtn').on('click', function () {

		var trObj = $(this).closest("tr");
		var ID = $(this).closest("tr").attr('id');
		var inputData = $(this).closest("tr").find(".editInput").serialize();

		// var inputjson = JSON.parse(JSON.stringify(inputData));
		// console.log(inputData);
		
		$.ajax({
			type: 'POST',
			url: 'http://localhost/ajax-table/index.php/home/editrow/',
			dataType: "json",
			data: 'action=edit&id=' + ID + '&' + inputData,
			success: function (response) {
				if (response.status == 'ok') {
					alert("User Updated Successful.");
					window.location.reload();

					
					// trObj.find(".editSpan.name").text(response.data.name);
					// trObj.find(".editSpan.contact_no").text(response.data.contact_no);
					// trObj.find(".editSpan.hobby").text(response.data.hobby);
					// trObj.find(".editSpan.category").text(response.data.category);
					
					// trObj.find(".editInput.name").text(response.data.name);
					// trObj.find(".editInput.contact_no").text(response.data.contact_no);
					// trObj.find(".editInput.hobby").text(response.data.hobby);
					// trObj.find(".editInput.category").text(response.data.category);
				

					// trObj.find(".editInput").hide();
                    // trObj.find(".saveBtn").hide();
                    
					// trObj.find(".editSpan").show();
					// trObj.find(".editBtn").show();
				} else {
					alert(response.msg);
				}
			}
		});


	});


	$('.deleteBtn').on('click', function () {
		//hide delete button
		$(this).closest("tr").find(".deleteBtn").hide();

		//show confirm button
		$(this).closest("tr").find(".confirmBtn").show();

	});

	$('.confirmBtn').on('click', function () {
		var trObj = $(this).closest("tr");
		var ID = $(this).closest("tr").attr('id');

		$.ajax({
			type: 'POST',
			url: 'http://localhost/ajax-table/index.php/home/deleterow/',
			dataType: "json",
			data: 'id=' + ID,
			success: function (response) {
				if (response.status == 'ok') {
					trObj.remove();
				} else {
					trObj.find(".confirmBtn").hide();
					trObj.find(".deleteBtn").show();
					alert(response.msg);
				}
			}
		});
	});
});


// *********************************************
$(document).ready(function () {


    $('#master').on('click',function(e){
        if(this.checked){
			$('.sub_chk').each(function(){
                this.checked = true;
            });
        }else{
			$('.sub_chk').each(function(){
                this.checked = false;
            });
        }
    });
	
	$('.sub_chk').on('click',function(e){
		if ($('.sub_chk:checked').length == $('.sub_chk').length){
            $('#master').prop('checked',true);
        }else{
            $('#master').prop('checked',false);
        }
    });



	$('.delete_all').on('click', function (e) {

		var allVals = [];
		$(".sub_chk:checked").each(function () {
			allVals.push($(this).attr('data-id'));
		});

		if (allVals.length <= 0) {
			alert("Please select row.");
		} else {

			var check = confirm("Are you sure you want to delete this row?");
			if (check == true) {

				var join_selected_values = allVals.join(",");

				$.ajax({
					url: $(this).data('url'),
					type: 'POST',
					data: 'ids=' + join_selected_values,
					success: function (data) {
						console.log(data);
						$(".sub_chk:checked").each(function () {
							$(this).parents("tr").remove();
						});
						alert("Item Deleted successfully.");
					},
					error: function (data) {
						alert(data.responseText);
					}
				});

				$.each(allVals, function (index, value) {
					$('table tr').filter("[data-row-id='" + value + "']").remove();
				});
			}
		}
	});
});